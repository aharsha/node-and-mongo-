import PropsEx from "./PropsEx";
import PropsExFc from "./PropsExFc";
import Table from "./Table";

function App() {
  return (
    <div>
      <Table tableNum="5" />
      
    </div>
  );
}
export default App;
