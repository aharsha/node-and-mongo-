function ProductArray()
{
//var  products = ['acer','lenovo','hp']; 
   //products =['abc','bb']; -> valid

  const products = ['acer','lenovo','hp'];
  //products =['abc','bb']; -> valid ->invalid
   products[0]= 'sony';
    return(
        <div>
            
            {
                //products.map(x=><li> {x}</li>)
                products.map(function(x)
                {
                   return <li> {x}</li>
                })
            }
        </div>
    )
}

export  default ProductArray;