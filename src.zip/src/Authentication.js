import React, {Component} from 'react'
 class Authentication extends React.Component {
   constructor(props) {
     super(props);
     this.state = {
       loginInfo: true,
          };
   }
   

   render() {
     if (this.state.loginInfo) {
       return (
         <div>
            <button >Logout</button>
         </div>
       );
     } else {
       return (
         <div>
            <button >Login</button>
         </div>
       );
     }
   }
 }
 export default Authentication;