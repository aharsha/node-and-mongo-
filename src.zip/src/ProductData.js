const ProductList= () =>
{
    return(
                      
        <ul>
        <li>Dell </li>
        <li>Lenovo </li>
        <li>Hp </li>
        </ul>
        );
    
}
export default ProductList;