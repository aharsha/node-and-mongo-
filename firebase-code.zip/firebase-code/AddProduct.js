import React, { Component } from 'react';
import firebase from './firebaseconfig';
class AddProduct extends Component {

    constructor(props)
    {
       super(props);
       this.state = 
       {
           proid: '',
           proname: '',
           proprice: ''
       }
    }
    storeField(e)
    {
       this.setState({[e.target.name]: e.target.value})
    }

    addProduct(e)
    {
        e.preventDefault();
        const product =
        {
            productid: this.state.proid,
            productname:this.state.proname,
            productPrice: this.state.proprice
        }
        console.log("product data = "+product);
        //send this product to database->our database is firbase
        //create firebase reffrence
        const fbRef=firebase.database().ref('products');
        console.log("reff = "+fbRef);
        //push data(product) into firebase using firebase reffrence
        fbRef.push(product);
    }
    render() {
        return (
            <div>
              <form onSubmit={this.addProduct.bind(this)}>
                  <div>
                  <label>ProductId </label>
                  <input  type="text" name="proid" onChange={this.storeField.bind(this)} />
                  </div>
                  <div>
                  <label>ProductName </label>
                  <input  type="text" name="proname" onChange={this.storeField.bind(this)} />
                  </div>
                  <div>
                  <label>ProductPrice </label>
                  <input  type="text" name="proprice" onChange={this.storeField.bind(this)} />
                  </div>
                  <button type="submit">addproduct </button>
              </form>  
            </div>
        );
    }
}

export default AddProduct;