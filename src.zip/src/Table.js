import  React , {Component}  from 'react';
import TableChild from './TableChild';
class Table extends React.Component {
  constructor(props) {
    console.log("Table cons executing");
    super(props);

    this.state = {
      num: this.props.tableNum,
    };
  }

  doSqr() {
    console.log(this);
    this.setState({
      num: this.state.num * this.state.num,
    });
  }

  //used to control dom updation
  static getDerivedStateFromProps(props,state)
{
  console.log(" Table getDerivedStateFromProps executing");
  if(state.num>1000)
  {
  //here state reintialising with parent props value
  state.num=props.tableNum;
return state.num ;
  }
  else{
    return null;
  }
}
componentDidMount()
{
  console.log(" Table DidMount execution");
}
componentDidUpdate(p,s)
{
console.log('props value'+p.tableNum+' preveous state value'+s.num);
}
  render() {
    console.log(" Table rendor executing ");
    return (
      <div>
        <p> {this.state.num}</p>
        <button onClick={this.doSqr.bind(this)}>GetSquare </button>

        <TableChild x="120"/>
      </div>
    );
  }
}
export  default Table;