import AddProduct from "./AddProduct";
import DisplayProducts from "./DisplayProducts";

function App() {
  return (
    <div>
     <DisplayProducts />
     <AddProduct />
    </div>
  );
}
export default App;
