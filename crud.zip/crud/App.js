import AddProduct from "./AddProduct";



function App() {
  return (
    <div className="App">
      <AddProduct />
    </div>
  );
}

export default App;
