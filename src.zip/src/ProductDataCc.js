import React, {Component} from 'react'
 class ProductListCc extends  React.Component
{
    render()
    {
        return(
                    
            <ul>
            <li>thoshiba </li>
            <li>Sony </li>
            <li>Apple </li>
            </ul>
            );
    }
}

export default ProductListCc;