import DisplayProducts from "./DisplayProducts";

function App() {
  return (
    <div>
     <DisplayProducts />
    </div>
  );
}
export default App;
