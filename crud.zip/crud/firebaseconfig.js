import firebase from 'firebase';
const config = {
    apiKey: "AIzaSyB10w5LYWEN02OhN2EWFgvQ2TzVl3CqEM0",
    authDomain: "product-store-9033d.firebaseapp.com",
    projectId: "product-store-9033d",
    storageBucket: "product-store-9033d.appspot.com",
    messagingSenderId: "776259627662",
    appId: "1:776259627662:web:368065f830222f0a85b7df",
    measurementId: "G-RF8RNQNJ8J"
  };
  // Initialize Firebase
  firebase.initializeApp(config);

  export default firebase;