import  React , {Component}  from 'react';
class TableChild extends React.Component {
  
constructor()
{
    console.log(" Table-Child cons executing");
    super();
}
 

  //used to control dom updation
  static getDerivedStateFromProps(props,state)
{
  console.log(" Table-Child getDerivedStateFromProps executing");
  
    return null;
  }

componentDidMount()
{
  console.log(" Table-Child DidMount execution");
}
componentDidUpdate(p,s)
{
console.log('Table-Child value'+p.x);
}
render() 
{
    console.log(" Table rendor executing ");
    return (
      <div>
        <div> TableChild</div>

       
      </div>
    );
  }
}

export  default TableChild;