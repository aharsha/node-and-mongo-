run backend file(node)
->run eshopapi.js file using 
node eshopapi.js  

test api in postman 
if api is properly working then use this api at front end


run frontend file(react)
create project ->create-react-app projectname

run the project npm start

