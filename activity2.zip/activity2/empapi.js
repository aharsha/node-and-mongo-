//load express module
var expressModule = require('express');
//create express object
var expressObject = expressModule();
//load mongodb module
var mongodbModule = require('mongodb');
//create mongodb object
mongoDbObject = mongodbModule.MongoClient;
var empList;

var bodyParser = require("body-parser");
expressObject.use(bodyParser.urlencoded({ extended: false }));
expressObject.use(bodyParser.json());

var url = "mongodb://localhost:27017/funlab";
mongoDbObject.connect(url, function (err, connection) {
    if (err) throw err;
    console.log("MongoDb Connected");
    //create database object
    dbObject = connection.db("funlaborg");
    console.log("  Database object created on funlaborg database ");
});

//create api ->return mock-data
//get function of expressObject can process http get request 
expressObject.get('/getemployees', function (req, res) {
    
    dbObject.collection("employee").find({}).toArray(function (err, result) {
        if (err) throw err;
        empList = result;
        console.log(empList);
        res.send(empList);
    });

});

expressObject.post('/addemp', function (req, res) {
    //create empData object and assign request body data to empData object
    var empData = {
         empid:   req.body.eid,
         empname: req.body.ename,
         empsal:  req.body.esal
        };
    console.log(empData);
    dbObject.collection("employee").insertOne(empData, function (err, rs) {
        if (err) throw err;
        console.log("1 document inserted");
    });
    res.send("product added successfully");
});

//create server using express object
var server = expressObject.listen(5050, function () {
    console.log('Node server is running..');
});