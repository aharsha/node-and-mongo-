function PropsExFc(p)
{
    return(
        <div> Welcome to {p.techName}
         </div>
         );
}

export  default PropsExFc;